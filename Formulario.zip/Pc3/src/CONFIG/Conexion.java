package CONFIG;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    public Connection conectar() {
        Connection con = null;
        try {
            String url = "jdbc:mysql://localhost:3306/bd_empleado?useTimezone=true&serverTimezone=UTC";
            String user = "root";
            String pass = "root";
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexión exitosa a bd_empleado");
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
        return con;
    }
}    