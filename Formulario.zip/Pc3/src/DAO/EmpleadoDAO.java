package DAO;

import CONFIG.Conexion;
import MOdelo.Empleado;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {
    Conexion cn = new Conexion();

    // LISTAR
    public List<Empleado> listar() {
        List<Empleado> lista = new ArrayList<>();
        String sql = "SELECT id, codigo, nombre, fecha_ingreso, cargo, area, sueldo_total, descuento, sueldo_neto FROM empleado";
        try (Connection con = cn.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Empleado e = new Empleado(
                    rs.getInt("id"),
                    rs.getString("codigo"),
                    rs.getString("nombre"),
                    rs.getString("fecha_ingreso"),
                    rs.getString("cargo"),
                    rs.getString("area"),
                    rs.getDouble("sueldo_total"),
                    rs.getDouble("descuento"),
                    rs.getDouble("sueldo_neto")
                );
                lista.add(e);
            }
        } catch (Exception ex) {
            System.out.println("Error listar: " + ex.getMessage());
        }
        return lista;
    }

    // AGREGAR (no pasa id)
    public int agregar(Empleado emp) {
        String sql = "INSERT INTO empleado (codigo, nombre, fecha_ingreso, cargo, area, sueldo_total, descuento, sueldo_neto) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection con = cn.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emp.getCodigo());
            ps.setString(2, emp.getNombre());
            ps.setString(3, emp.getFechaIngreso());
            ps.setString(4, emp.getCargo());
            ps.setString(5, emp.getArea());
            ps.setDouble(6, emp.getSueldoTotal());
            ps.setDouble(7, emp.getDescuento());
            ps.setDouble(8, emp.getSueldoNeto());
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("Error agregar: " + ex.getMessage());
        }
        return 0;
    }

    // ACTUALIZAR (usa id)
    public int actualizar(Empleado emp) {
        String sql = "UPDATE empleado SET codigo=?, nombre=?, fecha_ingreso=?, cargo=?, area=?, sueldo_total=?, descuento=?, sueldo_neto=? WHERE id=?";
        try (Connection con = cn.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emp.getCodigo());
            ps.setString(2, emp.getNombre());
            ps.setString(3, emp.getFechaIngreso());
            ps.setString(4, emp.getCargo());
            ps.setString(5, emp.getArea());
            ps.setDouble(6, emp.getSueldoTotal());
            ps.setDouble(7, emp.getDescuento());
            ps.setDouble(8, emp.getSueldoNeto());
            ps.setInt(9, emp.getId());
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("Error actualizar: " + ex.getMessage());
        }
        return 0;
    }

    // ELIMINAR por id
    public int eliminar(int id) {
        String sql = "DELETE FROM empleado WHERE id=?";
        try (Connection con = cn.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("Error eliminar: " + ex.getMessage());
        }
        return 0;
    }

    // BUSCAR por codigo (opcional)
    public Empleado buscarPorCodigo(String codigo) {
        String sql = "SELECT id, codigo, nombre, fecha_ingreso, cargo, area, sueldo_total, descuento, sueldo_neto FROM empleado WHERE codigo=?";
        try (Connection con = cn.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Empleado(
                        rs.getInt("id"),
                        rs.getString("codigo"),
                        rs.getString("nombre"),
                        rs.getString("fecha_ingreso"),
                        rs.getString("cargo"),
                        rs.getString("area"),
                        rs.getDouble("sueldo_total"),
                        rs.getDouble("descuento"),
                        rs.getDouble("sueldo_neto")
                    );
                }
            }
        } catch (Exception ex) {
            System.out.println("Error buscarPorCodigo: " + ex.getMessage());
        }
        return null;
    }
}