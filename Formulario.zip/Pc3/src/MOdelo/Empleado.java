
package MOdelo;

public class Empleado {
    private int id;
    private String codigo;
    private String nombre;
    private String fechaIngreso;
    private String cargo;
    private String area;
    private double sueldoTotal;
    private double descuento;
    private double sueldoNeto;
    
    public Empleado(String codigo, String nombre, String fechaIngreso, String cargo, String area, double sueldoTotal) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.cargo = cargo;
        this.area = area;
        this.sueldoTotal = sueldoTotal;
        if (this.sueldoTotal > 1800) {
            this.descuento = this.sueldoTotal * 0.10;
        } else {
            this.descuento = 0;
        }
        this.sueldoNeto = this.sueldoTotal - this.descuento;
    }
    
    public Empleado(int id, String codigo, String nombre, String fechaIngreso, String cargo, String area, double sueldoTotal, double descuento, double sueldoNeto) {
        this.id = id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.cargo = cargo;
        this.area = area;
        this.sueldoTotal = sueldoTotal;
        this.descuento = descuento;
        this.sueldoNeto = sueldoNeto;
    }

    public Empleado() { }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public double getSueldoTotal() {
        return sueldoTotal;
    }

    public void setSueldoTotal(double sueldoTotal) {
        this.sueldoTotal = sueldoTotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getSueldoNeto() {
        return sueldoNeto;
    }

    public void setSueldoNeto(double sueldoNeto) {
        this.sueldoNeto = sueldoNeto;
    }

    

    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", codigo='" + codigo + '\'' + ", nombre='" + nombre + '\'' +
               ", fechaIngreso='" + fechaIngreso + '\'' + ", cargo='" + cargo + '\'' + ", area='" + area + '\'' +
               ", sueldoTotal=" + sueldoTotal + ", descuento=" + descuento + ", sueldoNeto=" + sueldoNeto + '}';
    }
}