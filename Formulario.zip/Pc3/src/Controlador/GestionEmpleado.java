
package Controlador;

import MOdelo.Empleado;
import java.util.ArrayList;

public class GestionEmpleado {
    private ArrayList<Empleado> lista = new ArrayList<>();

    // Generar códigos E001, E002...
    public String generarCodigo() {
        int numero = lista.size() + 1;
        return String.format("E%03d", numero);
    }

    // CREATE
    public void agregar(Empleado emp) {
        lista.add(emp);
    }

    // READ - Buscar por código
    public Empleado buscar(String codigo) {
        for (Empleado e : lista) {
            if (e.getCodigo().equalsIgnoreCase(codigo)) {
                return e;
            }
        }
        return null;
    }

    // UPDATE
    public boolean actualizar(Empleado empNuevo) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equals(empNuevo.getCodigo())) {
                lista.set(i, empNuevo);
                return true;
            }
        }
        return false;
    }

    // DELETE
    public boolean eliminar(String codigo) {
        Empleado e = buscar(codigo);
        if (e != null) {
            lista.remove(e);
            return true;
        }
        return false;
    }

    public ArrayList<Empleado> getLista() {
        return lista;
    }
}
